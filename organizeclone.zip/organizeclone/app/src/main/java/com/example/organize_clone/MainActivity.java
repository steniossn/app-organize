package com.example.organize_clone;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.heinrichreimersoftware.materialintro.app.IntroActivity;
import com.heinrichreimersoftware.materialintro.slide.SimpleSlide;

public class MainActivity extends IntroActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);

        //criar a tela em slider
        addSlide(new SimpleSlide.Builder()
                .title("titulo")
                .description("descrição")
                .background(android.R.color.holo_blue_bright)
                .image(R.drawable.casa)
                .build()
        );
    }
}
